/**
*@file AddUserCreatedItemsMenu.h
*@brief Declares menu which will ask if the user wants to add user created items to their Character
*/