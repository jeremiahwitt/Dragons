var searchData=
[
  ['image',['image',['../class_item.html#add84a42b692ee5d580a92ae4a922f784',1,'Item']]],
  ['image_2eh',['image.h',['../image_8h.html',1,'']]],
  ['incrementdefense',['incrementDefense',['../class_armor.html#a2acffb5e791465d3c6bef5bfa86e8926',1,'Armor::incrementDefense()'],['../class_shield.html#a4031510f895e4163ee2b447d7992e08b',1,'Shield::incrementDefense()']]],
  ['incrementrange',['incrementRange',['../class_shield.html#a2e36b34d593ce4de9066c206c3528846',1,'Shield::incrementRange()'],['../class_weapon.html#a7dd6eff2cc572adb9bef4b985a255920',1,'Weapon::incrementRange()']]],
  ['inithitpoints',['initHitPoints',['../class_fighter.html#a5bfd7630b47d4bf3b7b1288195bbad07',1,'Fighter']]],
  ['insertitem',['insertItem',['../class_container.html#a512e6e65360249dc2fcd1aa5f466a01e',1,'Container']]],
  ['interactenvironment',['interactEnvironment',['../class_game_play_engine.html#a2a0f5663a43825bbd815d6bfe92bd8fb',1,'GamePlayEngine']]],
  ['interactwithcontainer',['interactWithContainer',['../class_fighter.html#a66c0adfa4979fa3ac994359a188121a8',1,'Fighter']]],
  ['iscellanobstruction',['isCellAnObstruction',['../class_map_editor_engine.html#aa8f2eec7f99782943317f61e0ff98123',1,'MapEditorEngine']]],
  ['iscomponentobstructiontoplayer',['isComponentObstructionToPlayer',['../class_environment.html#a7427445e57ccdb66b13ede6ed151263c',1,'Environment']]],
  ['isempty',['isEmpty',['../class_character_save_map.html#ab184ee82d93d3e907a582f1924f05990',1,'CharacterSaveMap']]],
  ['isoccupied',['isOccupied',['../class_map_editor_engine.html#ab06dd22cc63e93a5d773bb8519e893d6',1,'MapEditorEngine']]],
  ['isplayeroncell',['isPlayerOnCell',['../class_map_editor_engine.html#a6cb1311e775978847a2e8f3db740def8',1,'MapEditorEngine']]],
  ['item',['Item',['../class_item.html',1,'Item'],['../class_item.html#a297720c02984eab37332ae795d22189d',1,'Item::Item()'],['../class_item.html#a2f0671713504024a4b63cd63c835f759',1,'Item::Item(const Item *otherItem)']]],
  ['itemcreator',['ItemCreator',['../class_item_creator.html',1,'']]],
  ['itemfactory',['ItemFactory',['../class_item_factory.html',1,'']]],
  ['itemfactory_2ecpp',['ItemFactory.cpp',['../_item_factory_8cpp.html',1,'']]],
  ['itemfactory_2eh',['ItemFactory.h',['../_item_factory_8h.html',1,'']]]
];
