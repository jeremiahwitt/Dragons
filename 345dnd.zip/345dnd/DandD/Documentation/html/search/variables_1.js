var searchData=
[
  ['enchantmentspossible',['enchantmentsPossible',['../class_item.html#a02a91e8112849f4e2fde342b0c9a0d47',1,'Item']]],
  ['enchantmentvalues',['enchantmentValues',['../class_item.html#a8532d8729f9433f41b7fc18b20d83236',1,'Item']]]
];
