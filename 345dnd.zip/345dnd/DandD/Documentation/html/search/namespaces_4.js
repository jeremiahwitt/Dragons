var searchData=
[
  ['halflings',['Halflings',['../namespace_halflings.html',1,'']]],
  ['humans',['Humans',['../namespace_humans.html',1,'']]]
];
