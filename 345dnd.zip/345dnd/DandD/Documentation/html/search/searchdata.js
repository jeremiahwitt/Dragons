var indexSectionsWithContent =
{
  0: "_abcdefghilmnoprstuvw~",
  1: "abcdefghilmoprstw",
  2: "bcdehmow",
  3: "cdefgilmnprstuw",
  4: "_abcdefghilmnoprstuvw~",
  5: "cei",
  6: "rst"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enums"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Enumerations"
};

