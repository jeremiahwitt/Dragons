var searchData=
[
  ['userinputandstringmanager_2ecpp',['userinputandstringmanager.cpp',['../userinputandstringmanager_8cpp.html',1,'']]],
  ['userinputandstringmanager_2eh',['userinputandstringmanager.h',['../userinputandstringmanager_8h.html',1,'']]]
];
