var searchData=
[
  ['_5fvalidcomponentposition',['_validComponentPosition',['../class_characters.html#af2c85f79c62aba2dbf3e8d77e20ffb52',1,'Characters']]],
  ['_5fvalidposition',['_validPosition',['../class_characters.html#ab509433a15fb7604b2080e0568e41d0d',1,'Characters']]]
];
