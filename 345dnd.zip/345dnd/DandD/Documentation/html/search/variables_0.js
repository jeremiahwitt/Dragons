var searchData=
[
  ['charrace',['charRace',['../class_entity.html#af1e600508552c74e578dc3258e2175c5',1,'Entity']]]
];
