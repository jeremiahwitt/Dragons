var searchData=
[
  ['fighter',['Fighter',['../class_fighter.html',1,'']]]
];
