var searchData=
[
  ['notify',['Notify',['../class_subject.html#afdf01736ff099d286543b450d96215f1',1,'Subject']]]
];
