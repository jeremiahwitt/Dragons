var searchData=
[
  ['belt',['Belt',['../class_belt.html#a6dc40c21b5a62c71925df189511d7551',1,'Belt::Belt()'],['../class_belt.html#a0fe7148ac3d4fba7953f89cd1ca00443',1,'Belt::Belt(const Belt *otherBelt)']]],
  ['boots',['Boots',['../class_boots.html#abad208e963b53b1f29e269fc246a3485',1,'Boots::Boots()'],['../class_boots.html#ad3452c78ef60ba4d955e779560d5e5ba',1,'Boots::Boots(const Boots *otherBoots)']]]
];
