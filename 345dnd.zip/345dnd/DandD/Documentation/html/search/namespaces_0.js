var searchData=
[
  ['basemenucolorindex',['BaseMenuColorIndex',['../namespace_base_menu_color_index.html',1,'']]]
];
