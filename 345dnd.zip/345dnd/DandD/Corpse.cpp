#include "Corpse.h"


Corpse::Corpse()
{
}


Corpse::~Corpse()
{
}
