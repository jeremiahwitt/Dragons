format should be as follows

name of map
campaign associated name